ENGINE_DIR=/app/examples/qwen/tmp/Qwen2.5/7B/trt_engines/fp16/1-gpu-target
DRAFT_ENGINE_DIR=/app/examples/qwen/tmp/Qwen2.5/0.5B/trt_engines/fp16/1-gpu
TENSORRT_LLM_DRAFT_MODEL_NAME="tensorrt_llm_draft"
TENSORRT_LLM_MODEL_NAME="tensorrt_llm"
TOKENIZER_DIR=/app/examples/qwen/tmp/Qwen2.5/7B
MODEL_FOLDER=/triton_model_repo_speculative_decoding
TRITON_MAX_BATCH_SIZE=4
INSTANCE_COUNT=4
MAX_QUEUE_DELAY_MS=10000
MAX_QUEUE_SIZE=0
FILL_TEMPLATE_SCRIPT=/app/tools/fill_template.py
DECOUPLED_MODE=false
LOGITS_DATATYPE=TYPE_FP32
KV_CACHE_FREE_GPU_MEM_FRACTION=0.4
ENABLE_KV_CACHE_REUSE=true
MAX_TOKEN_IN_PAGED_KV_CACHE=2048*8
DRAFT_GPU_DEVICE_IDS=0
ENABLE_CHUNKED_CONTEXT=false

cp -R /app/all_models/inflight_batcher_llm/* ${MODEL_FOLDER}
mkdir -p tensorrt_llm_draft
cp -R ${MODEL_FOLDER}/tensorrt_llm/* ${MODEL_FOLDER}/tensorrt_llm_draft

python3 ${FILL_TEMPLATE_SCRIPT} -i ${MODEL_FOLDER}/ensemble/config.pbtxt triton_max_batch_size:${TRITON_MAX_BATCH_SIZE},logits_datatype:${LOGITS_DATATYPE}
python3 ${FILL_TEMPLATE_SCRIPT} -i ${MODEL_FOLDER}/preprocessing/config.pbtxt tokenizer_dir:${TOKENIZER_DIR},triton_max_batch_size:${TRITON_MAX_BATCH_SIZE},preprocessing_instance_count:${INSTANCE_COUNT}
python3 ${FILL_TEMPLATE_SCRIPT} -i ${MODEL_FOLDER}/tensorrt_llm/config.pbtxt triton_backend:tensorrtllm,triton_max_batch_size:${TRITON_MAX_BATCH_SIZE},decoupled_mode:${DECOUPLED_MODE},max_queue_delay_microseconds:${MAX_QUEUE_DELAY_MS},max_queue_size:${MAX_QUEUE_SIZE},engine_dir:${ENGINE_DIR},batching_strategy:inflight_fused_batching,encoder_input_features_data_type:TYPE_FP16,logits_datatype:${LOGITS_DATATYPE},enable_kv_cache_reuse:${ENABLE_KV_CACHE_REUSE},max_tokens_in_paged_kv_cache:${MAX_TOKEN_IN_PAGED_KV_CACHE},enable_chunked_context:${ENABLE_CHUNKED_CONTEXT}
python3 ${FILL_TEMPLATE_SCRIPT} -i ${MODEL_FOLDER}/postprocessing/config.pbtxt tokenizer_dir:${TOKENIZER_DIR},triton_max_batch_size:${TRITON_MAX_BATCH_SIZE},postprocessing_instance_count:${INSTANCE_COUNT},max_queue_size:${MAX_QUEUE_SIZE}

## Speculative sampling ###
sed -i 's/name: "tensorrt_llm"/name: "tensorrt_llm_draft"/g' ${MODEL_FOLDER}/tensorrt_llm_draft/config.pbtxt
python3 ${FILL_TEMPLATE_SCRIPT} -i ${MODEL_FOLDER}/tensorrt_llm_bls/config.pbtxt triton_max_batch_size:${TRITON_MAX_BATCH_SIZE},decoupled_mode:${DECOUPLED_MODE},bls_instance_count:${INSTANCE_COUNT},logits_datatype:${LOGITS_DATATYPE},tensorrt_llm_model_name:${TENSORRT_LLM_MODEL_NAME},tensorrt_llm_draft_model_name:${TENSORRT_LLM_DRAFT_MODEL_NAME}
python3 ${FILL_TEMPLATE_SCRIPT} -i ${MODEL_FOLDER}/tensorrt_llm_draft/config.pbtxt triton_backend:tensorrtllm,triton_max_batch_size:${TRITON_MAX_BATCH_SIZE},decoupled_mode:${DECOUPLED_MODE},max_queue_delay_microseconds:${MAX_QUEUE_DELAY_MS},max_queue_size:${MAX_QUEUE_SIZE},engine_dir:${DRAFT_ENGINE_DIR},batching_strategy:inflight_fused_batching,encoder_input_features_data_type:TYPE_FP16,logits_datatype:${LOGITS_DATATYPE},enable_kv_cache_reuse:${ENABLE_KV_CACHE_REUSE},max_tokens_in_paged_kv_cache:${MAX_TOKEN_IN_PAGED_KV_CACHE},gpu_device_ids:${DRAFT_GPU_DEVICE_IDS},gpt_model_path:${gpt_model_path}
python3 /app/scripts/launch_triton_server.py --world_size=1 --model_repo=/triton_model_repo_speculative_decoding --http_port=14524 --tensorrt_llm_model_name "tensorrt_llm,tensorrt_llm_draft"